// Copyright 2011 Google Inc. All Rights Reserved.

/**
 * @fileoverview Defined the convenience function cvox.Msgs.getMsg.
 * @author deboer@google.com (James deBoer)
 */

goog.provide('cvox.Msgs');


/**
 * The namespace for all Chromevox messages.
 * @type {string}
 * @const
 * @private
 */
cvox.Msgs.NAMESPACE_ = 'chromevox_';


/**
 * Returns the message with the given message id from the ChromeVox namespace.
 *
 * If we can't find a message, throw an exception.  This allows us to catch
 * typos early.
 *
 * @param {string} message_id The id.
 * @return {string} The message.
 */
cvox.Msgs.getMsg = function(message_id) {
  var message = chrome.i18n.getMessage(cvox.Msgs.NAMESPACE_ + message_id);
  if (message == undefined || message == '') {
    throw 'Invalid ChromeVox message id: ' + message_id;
  }
  return message;
};


/**
 * Processes an HTML DOM the text of "i18n" elements with translated messages.
 * This function expects HTML elements with a i18n clean and a msgid attribute.
 *
 * @param {Node} root The root node where the translation should be performed.
 */
cvox.Msgs.addTranslatedMessagesToDom = function(root) {
  var elts = root.querySelectorAll('.i18n');
  for (var i = 0; i < elts.length; i++) {
    elts[i].textContent = cvox.Msgs.getMsg(elts[i].getAttribute('msgid'));
  }
};
